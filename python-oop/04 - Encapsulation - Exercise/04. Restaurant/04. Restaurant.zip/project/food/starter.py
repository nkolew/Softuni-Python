from project import Food


class Starter(Food):
    pass